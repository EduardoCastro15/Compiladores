## LL1 Parser

[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/hatamiarash7/LL1_Parser/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/hatamiarash7/LL1_Parser/?branch=master)

LL1 parser written in Python

### Parser Features
* First and Follow Sets
* Build Parsing Table
* Take String and check whether the string is accepted or rejected by the grammar
