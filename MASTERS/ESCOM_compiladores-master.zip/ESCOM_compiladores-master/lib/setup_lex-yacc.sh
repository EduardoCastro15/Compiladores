#!/usr/bin/env bash

apt install flex libfl-dev bison bison-doc -y
