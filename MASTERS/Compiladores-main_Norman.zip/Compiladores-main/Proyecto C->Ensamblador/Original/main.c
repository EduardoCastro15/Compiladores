#include "bison.tab.h"

int main(){
	yyparse();
	return 0;
}
