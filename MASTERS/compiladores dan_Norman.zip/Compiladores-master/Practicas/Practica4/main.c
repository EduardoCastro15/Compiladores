int main(void)
{
	yylex();
	return 0;
}