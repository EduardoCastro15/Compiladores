## Para poder correr este programa por favor incluya el .jar de Jaccie en su proyecto. Este puede ser descargado desde: 
http://www2.cs.unibw.de/Tools/Syntax/english/download.html
