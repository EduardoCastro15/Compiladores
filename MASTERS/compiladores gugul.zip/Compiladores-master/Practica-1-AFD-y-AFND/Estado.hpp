#ifndef _ESTADO_HPP_
#define _ESTADO_HPP_

class Estado {
public:
  int numeroDeEstado;
  bool esFinal;
  Estado();
  Estado(int numDeEstado, bool tipo);};

#endif
