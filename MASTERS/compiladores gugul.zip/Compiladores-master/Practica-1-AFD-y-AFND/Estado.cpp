#include "Estado.hpp"

Estado::Estado(int numDeEstado, bool tipo)
{
	numeroDeEstado = numDeEstado;
	esFinal = tipo;
}
