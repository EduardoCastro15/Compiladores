#include "Estado.hpp"

/**
 * Constructor
 * **/
Estado::Estado(int numDeEstado, bool tipo)
{
	numeroDeEstado = numDeEstado;
	esFinal = tipo;
}
