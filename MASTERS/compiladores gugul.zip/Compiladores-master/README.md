# COMPILADORES

Prácticas de la materia de Compiladores, hechas en C++ (a excepción del ejemplo de Jaccie que esta en Java y el proyecto en Python).

## Compilacion de las prácticas
```
Linux: Tan facil como escribir "make" 
```
```
Para el ejemplo de Jaccie, crear el proyecto en su IDE de preferencia, leer el Readme de la práctica 4.
```
```
Windows: No ha sido probado aún.
```
### Requisitos

Tener make instalado en tu sistema Linux (sudo apt-get install make). Facilita la compilación :)

### Extras

```
$make : Solo compila
```
```
$make run : ejecuta
```
```
$make clean : Elimina archivos objeto y el ejecutable
```
```
$make indent : Indenta el código (a veces no funciona bien).
```

## Autor

* **Ivan Ortega Victoriano** 
