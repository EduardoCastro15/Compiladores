package ll1;

public class Produccion {
    public Character simbolo;
    public String produccion;
    Produccion(Character simbolo, String produccion){
        this.simbolo = simbolo;
        this.produccion = produccion;
    }
}
